# GTA SA:MP Shader Studio v9.0

Final build-prep Android Studio project for the supplied base shader.

## Build on GitHub from an Android phone
1. Create a GitHub repository.
2. Upload the contents of this project (the `v9` folder contents) to the repository root.
3. Open **Actions**.
4. Run **Build APK** manually, or push to `main`/`master`.
5. Open the completed run and download the artifact `GTA-SA-MP-Shader-Studio-debug`.

## Local build
Requires JDK 17, Android SDK 35 and Gradle 8.7+. Run `gradle :app:assembleDebug`.

## Important
The preview is a lightweight approximation; it does not execute the full GTA runtime framebuffer. `libtest.so` is bundled as an asset and is copied/exported without modification.
